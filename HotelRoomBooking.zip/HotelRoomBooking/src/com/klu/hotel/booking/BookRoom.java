package com.klu.hotel.booking;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/BookRoom")
public class BookRoom extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {

	}

	@SuppressWarnings("deprecation")
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Integer rmCunt = Integer.valueOf(request.getParameter("noofroom"));
		String typeofroom = request.getParameter("typeofroom");
		String paymentType = request.getParameter("paymenttype");
		String checkin = request.getParameter("checkin");
		String checkout = request.getParameter("checkout");
		BigDecimal amt = BigDecimal.ZERO;
		BigDecimal tax = BigDecimal.ZERO;
		
		switch (typeofroom) {
		case "duble":
			amt = new BigDecimal(500);
			break;
		case "Quad":
			amt = new BigDecimal(1000);
			break;
		case "Twin":
			amt = new BigDecimal(1500);
			break;
		case "Deluxe":
			amt = new BigDecimal(2500);
			break;
		case "LuxurySuite":
			amt = new BigDecimal(3500);
			break;
		case "MasterSuite":
			amt = new BigDecimal(4500);
			break;
		}
		switch (paymentType) {
		case "Cash":
			tax = new BigDecimal(1);
			break;
		case "Card":
			tax = new BigDecimal(3);
			break;
		case "Cheque":
			tax = new BigDecimal(2);
			break;
		}
		
		long noOfDaysBetween = 0;
		try {
			LocalDate dateBefore = LocalDate.parse(checkout);
			LocalDate dateAfter = LocalDate.parse(checkin);

			noOfDaysBetween = ChronoUnit.DAYS.between(dateAfter, dateBefore);
		} catch (Exception e) {
			response.sendRedirect("errorpage.html");
		}

		if (rmCunt > 0 && !"".equals(typeofroom) && !"".equals(paymentType)) {
			amt = amt.add(amt.multiply(tax.divide(new BigDecimal(100))));
			
			request.setAttribute("noofroom", String.valueOf(rmCunt));
			request.setAttribute("noOfDaysBetween", String.valueOf(noOfDaysBetween));
			request.setAttribute("checkout", checkout);
			request.setAttribute("amt", String.valueOf(amt));
			request.getRequestDispatcher("roomDetails.jsp").forward(request, response);
		} else {
			response.sendRedirect("errorpage.html");
		}
	}

}
