package com.klu.hotel.booking;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class SignUpPage
 */
@WebServlet("/SignUpPage")
public class SignUpPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String FILE_PATH = "D:/Customers.txt";
	
	public void init(ServletConfig config) throws ServletException {
		try {
		File file = new File(FILE_PATH);
		if(!file.exists()) {
				file.createNewFile();
		}
		} catch (IOException e) {
			System.out.println("File is not Created, Due to some technical issues...");
		}
	}

	
	public void destroy() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StringBuilder fileContent = new StringBuilder();

		fileContent.append(request.getParameter("email")).append("_");
		fileContent.append(request.getParameter("pwd")).append("_");
		fileContent.append(request.getParameter("aadhaar")).append("_");
		fileContent.append(request.getParameter("pan")).append("_");
		fileContent.append(request.getParameter("fname")).append("_");
		fileContent.append(request.getParameter("lname")).append("_");
		fileContent.append(request.getParameter("gender")).append("_");
		fileContent.append(request.getParameter("dob")).append(";\n");

		try (BufferedWriter bw =new BufferedWriter(new FileWriter(FILE_PATH, true))) {
			bw.write(fileContent.toString());
			bw.close();
			response.sendRedirect("sucess.html");
		} catch (Exception e) {
			System.out.println("Customer is not Created, Due to some technical issues...");
			response.sendRedirect("errorpage.html");
		}

	}

}
