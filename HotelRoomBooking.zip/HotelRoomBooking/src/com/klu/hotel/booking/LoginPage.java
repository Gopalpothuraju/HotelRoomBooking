package com.klu.hotel.booking;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginPage")
public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String FILE_PATH = "D:/Customers.txt";

	@Override
	public void init() throws ServletException {

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			String userName = request.getParameter("username");
			String password = request.getParameter("pwd");
			
			String[] userDetails = null;
			boolean userLoggedIn = false;
			
			try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
				String userData = br.readLine();
				
				while(userData != null) {
					userDetails = userData.split("_");
					if(userName.equals(userDetails[0]) && password.equals(userDetails[1])){
						userLoggedIn = true;
						break;
					}
				}
			} catch (Exception e) {
				System.out.println("Customer is not Logged In successfully, Due to some technical issues...");
			}

			if(userLoggedIn) {
				request.setAttribute("username", userDetails[0]);
				request.setAttribute("aadhaar", userDetails[2]);
				request.setAttribute("pan", userDetails[3]);
				
				request.getRequestDispatcher("bookingpage.jsp").forward(request, response);
			}else {
				response.sendRedirect("errorpage.html");
			}
	}

}
